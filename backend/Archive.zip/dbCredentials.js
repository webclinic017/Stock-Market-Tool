const Credentials = {
    "username" : "DanielCanas",
    "password" : "WSgnHp2IM8zOmqov"
}

module.exports = Credentials;